/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aoner <aoner@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/29 16:22:39 by aoner             #+#    #+#             */
/*   Updated: 2023/04/30 17:55:33 by aoner            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "BitcoinExchange.hpp"

int main(int argc, char **argv)
{
	if (argc != 2)
	{
		std::cerr << "Error: could not open file";
		exit(EXIT_FAILURE);
	}
	else
	{
    	std::ifstream file;
    //	std::ifstream file2;
		std::vector<std::pair<std::string, std::string> > _v;
		//std::vector<std::pair<std::string, double> > _v_data;
		std::string line;
	//	std::string line2;
		size_t pos; 
	//	size_t pos2;
		std::string date;
		std::string value;
/* 		std::string date2;
		std::string val2;
        double		btc; */
		file.open(argv[1]);
		//file2.open("data.csv");
		if (!file /* || !file2 */)
		{
			std::cerr << "Error: could not open file";
			exit(EXIT_FAILURE);
		}
		while(std::getline(file, line) /*  || std::getline(file2, line2 )*/)
		{
			pos = line.find(" | ");
			//pos2 = line2.find(",");
			if (pos != std::string::npos)
			{
            	date = line.substr(0, pos);
            	value = line.substr(pos+3);
            	_v.push_back(std::make_pair(date, value));
        	}
			else
			{
				std::string date = line.substr(0, pos);
				_v.push_back(std::make_pair(date, "-1"));
			}
			/*
			if (pos2 != std::string::npos)
			{
            	date2 = line2.substr(0, pos2);
				val2 = line2.substr(pos2 + 1);
				btc = std::strtod(val2.c_str(), NULL);
            	_v_data.push_back(std::make_pair(date2, btc));
        	}
			else
			{
				date2 = line.substr(0, pos);
				_v.push_back(std::make_pair(date2, "-1"));
			} */
		}
		file.close();
		//file2.close();
		int i  = 0;
		for (std::vector<std::pair<std::string, std::string> >::const_iterator it = _v.begin(); it != _v.end(); ++it)
		{
			if (is_valid_date(it->first) == false)
			{
				std::cout << "Error: bad input" << std::endl;
				_v[i].first = "-1";
				_v[i].second = "-1";
			}
			else if (is_valid_value(it->second) == "false")
			{	
				std::cout << "Error: not a valid number" << std::endl;
				_v[i].first = "-1";
				_v[i].second = "-1";
			}
        	else
			{
				std::cout << it->first << " => " << it->second << std::endl;	
			}
			i++;
		}
/* 		for (std::vector<std::pair<std::string, double> >::const_iterator it = _v_data.begin(); it != _v_data.end(); ++it)
		{
			
			std::cout << it->first << " => " << it->second << std::endl;
		} */
	}
}













/* 
for (std::vector<std::pair<std::string, std::string> >::const_iterator it = _v.begin(); it != _v.end(); ++it)
{
	std::cout << it->first << " => " << it->second << std::endl;
}
*/